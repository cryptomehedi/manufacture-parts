import React from 'react';

const Blogs = () => {
    return (
        <div>
            <div className="text-xl font-semibold">Q. How will you improve the performance of a React Application?</div>
            <div>Ans. When developing any program, especially online apps, the number one item on any developer's attention is optimization. JS frameworks like as Angular, React, and others have some fantastic capabilities and customizations. Here, I'll go through the features and tips that will help you improve the performance of your app. Regardless of the precise optimization patterns and strategies you choose. It's critical to maintain your code DRY at all times. Always try to reuse components; this will help you write more efficient code. However, when working with huge codebases or several repositories, reusing code might be difficult for two reasons: 1. You are frequently ignorant of useful code.</div>
            <div className="text-xl font-semibold">Q.  What are the different ways to manage a state in a React application?</div>
            <div>Ans. There's one state management solution that I've personally tried to implement for as long as I've been using React, and with the release of React hooks (and massive improvements to React context) this method of state management has been drastically simplified.</div>
            <div></div>
            <div></div>
            <div></div>
        </div>
    );
};

export default Blogs;